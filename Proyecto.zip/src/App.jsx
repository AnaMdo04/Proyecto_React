import React, { useState } from "react";
import Presentacion from "./components/Presentacion";
import Juego from "./components/Juego";

function App() {
  const [mostrarJuego, setMostrarJuego] = useState(false);

  const iniciarJuego = () => {
    setMostrarJuego(true);
  };

  return (
    <div className="App">
      {mostrarJuego ? <Juego /> : <Presentacion iniciarJuego={iniciarJuego} />}
      <audio autoPlay loop>
        <source src={require("./img/musicaFondo.mp3")} type="audio/mpeg" />
        Tu navegador no soporta el elemento de audio.
      </audio>
    </div>
  );
}

export default App;
